import asyncio
import logging
from sqlalchemy.orm import Session

from app.core.database import SessionLocal

from app.models.document import Document
from app.models.document import ProcessingStatus

from app.ingestion.pipeline import IngestionPipeline

logger = logging.getLogger(__name__)


class IngestWorker:

    @staticmethod
    async def process_document(
        document_id: int,
    ):

        db: Session = SessionLocal()

        try:

            document = (
                db.query(Document)
                .filter(Document.id == document_id)
                .first()
            )

            if not document:
                return

            document.processing_status = (
                ProcessingStatus.PROCESSING
            )

            db.commit()

            pipeline = IngestionPipeline()

            await pipeline.run(
                document=document,
                db=db,
            )

            document.processing_status = (
                ProcessingStatus.READY
            )

            db.commit()

        except Exception as e:

            logger.exception(e)

            if document:

                document.processing_status = (
                    ProcessingStatus.FAILED
                )

                db.commit()

        finally:

            db.close()