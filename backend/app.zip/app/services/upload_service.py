import asyncio
from pathlib import Path

from fastapi import UploadFile
from sqlalchemy.orm import Session

from app.models.document import Document
from app.models.document import FileType
from app.models.document import ProcessingStatus

from app.services.storage_service import StorageService
from app.workers.ingest_worker import IngestWorker


class UploadService:

    @staticmethod
    async def upload_document(
        db: Session,
        file: UploadFile,
        uploaded_by: str,
    ) -> Document:
        """
        Upload a document to Supabase Storage,
        create a database record,
        and start background AI processing.
        """

        # Upload to Supabase Storage
        storage_path, file_url, file_size = await StorageService.upload_file(file)

        # Determine file type
        extension = Path(file.filename).suffix.replace(".", "").upper()

        try:
            file_type = FileType[extension]
        except KeyError:
            file_type = FileType.OTHER

        # Create database record
        document = Document(
            filename=file.filename,
            storage_path=storage_path,
            file_url=file_url,
            file_size=file_size,
            file_type=file_type,
            processing_status=ProcessingStatus.QUEUED,
            uploaded_by=uploaded_by,
        )

        db.add(document)
        db.commit()
        db.refresh(document)

        # Start ingestion in background
        asyncio.create_task(
            IngestWorker.process_document(document.id)
        )

        return document