from uuid import uuid4
from pathlib import Path

from fastapi import UploadFile

from app.db.supabase import supabase


class StorageService:
    BUCKET = "documents"

    @classmethod
    async def upload_file(
        cls,
        file: UploadFile,
    ) -> tuple[str, str]:
        """
        Upload file to Supabase Storage.

        Returns:
            storage_path
            public_url
        """

        extension = Path(file.filename).suffix.lower()

        filename = f"{uuid4()}{extension}"

        storage_path = f"documents/{filename}"

        content = await file.read()

        result = supabase.storage.from_(cls.BUCKET).upload(
            path=storage_path,
            file=content,
            file_options={
                "content-type": file.content_type,
                "upsert": "false",
            },
        )

        if hasattr(result, "error") and result.error:
            raise Exception(result.error.message)

        public_url = (
            supabase.storage
            .from_(cls.BUCKET)
            .get_public_url(storage_path)
        )

        return storage_path, public_url,len(content)